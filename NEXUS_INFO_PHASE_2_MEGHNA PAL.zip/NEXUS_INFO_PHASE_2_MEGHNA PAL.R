# Load data (replace with your dataset)
nexus_data <- read.csv("/Users/meghna/Downloads/twitter_sentiment_data.csv")
# Rename columns
colnames(nexus_data)[1] <- "target"
colnames(nexus_data)[2] <- "ids"
colnames(nexus_data)[3] <- "date"
colnames(nexus_data)[4] <- "flag"
colnames(nexus_data)[5] <- "user"
colnames(nexus_data)[6] <- "Text"
View(nexus_data)

library(shiny)
# Define UI for the application
ui <- fluidPage(
  titlePanel("Twitter Sentiment Analysis"),
  sidebarLayout(
    sidebarPanel(
      textInput("tweet", "Enter Tweet Text:", ""),
      actionButton("analyze", "Analyze Sentiment")
    ),
    mainPanel(
      textOutput("result")
    )
  )
)
# Define server logic for sentiment prediction
server <- function(input, output) {
  observeEvent(input$analyze, {
    new_tweet <- data.frame(text = clean_text(input$tweet), stringsAsFactors = FALSE)
    new_dtm <- DocumentTermMatrix(Corpus(VectorSource(new_tweet$text)), control = list(dictionary = Terms(dtm)))
    new_matrix <- as.matrix(new_dtm)
    prediction <- predict(model, new_matrix)
    output$result <- renderText({
      paste("Predicted Sentiment:", ifelse(prediction == 4, "Positive", ifelse(prediction == 0, "Negative", "Neutral")))
    })
  })
}
# Run the application
shinyApp(ui = ui, server = server)